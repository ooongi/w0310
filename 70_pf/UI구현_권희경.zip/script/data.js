// 데이터

export const data = [
    {
        img: "./images/section3/vehicles_gche.png",
        txt: "GRAND CHEROKEE L",
        txt2: "A LEGACY EXTENDED"
    },
    {
        img: "./images/section3/vehicles_renegade.png",
        txt: "RENEGADE",
        txt2: "BORN TO BE WILD"
    },
    {
        img: "./images/section3/vehicles_wrangler.png",
        txt: "WRANGLER",
        txt2: "FAMOUS FOR FREEDOM"
    },
    {
        img: "./images/section3/vehicles_avenger.png",
        txt: "AVENGER",
        txt2: "ELECTRIC ADVENTURE"
    },
];

// export default data;
